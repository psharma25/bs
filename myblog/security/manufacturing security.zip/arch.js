/*
 * Interactive reference-architecture model.
 * Every clickable element (a zone, a node, or an attack-graph step) maps to a
 * detail record with title, body, and cross-links into the guide's sections.
 * This is the same data that drives the SVG in the HTML.
 */

const ZONES = [
  {
    id: "users", name: "Users & stakeholders", x: 20, y: 60, w: 150, h: 250, color: "#e8eff4",
    detail: {
      title: "Users & stakeholders",
      body: "Everyone who touches the environment: employees, engineers, suppliers, partners, remote users, and — for medical devices — customers and patients. Each is an identity to authenticate and an attack path to control. Remote users and third-party suppliers are the highest-risk category because they cross your boundary from outside it.",
      controls: ["Individual accounts, never shared logins", "MFA on every remote path", "Least privilege by role"],
      link: "access",
    },
  },
  {
    id: "it", name: "Enterprise IT zone", x: 180, y: 60, w: 150, h: 250, color: "#EAF3DE",
    detail: {
      title: "Enterprise IT zone (Levels 4–5)",
      body: "The business side: corporate network, Active Directory / identity, email and collaboration, and ERP/PLM/CRM. This is where most attacks land first — phishing an employee, compromising a laptop — and where NotPetya spread at Merck. It must never talk directly to the plant floor.",
      controls: ["Segmented from OT (never direct)", "Identity federation, SSO, MFA", "Email security — the #1 entry point"],
      link: "itot",
    },
  },
  {
    id: "dmz", name: "DMZ", x: 340, y: 60, w: 130, h: 250, color: "#FAEEDA",
    detail: {
      title: "DMZ — the guarded checkpoint",
      body: "The buffer between IT and OT. All traffic crossing between the business and the plant floor STOPS here and is inspected: web/API gateways, patch and update repositories, secure file transfer, and the remote-access gateway. If an attacker is on the IT side, the DMZ is what stops them reaching a PLC directly.",
      controls: ["No direct IT↔OT flows — everything brokered here", "Patch repo so OT never pulls from the internet", "Remote access gateway with MFA and logging"],
      link: "purdue",
    },
  },
  {
    id: "ot", name: "Manufacturing (OT) zone", x: 480, y: 60, w: 250, h: 250, color: "#E6F1FB",
    detail: {
      title: "Manufacturing (OT) zone (Levels 0–3)",
      body: "The plant floor itself, in layers: operations & control (Historian, MES/MOM, SCADA, HMIs), the control network (PLCs/RTUs, edge gateways, I/O, robots and CNC controllers), and the field layer (sensors, actuators, drives/motors, and the medical devices being built). This is what plant security exists to protect — where a compromise stops production or endangers product.",
      controls: ["Micro-segment critical process zones", "Passive monitoring — never block blindly", "Protect PLC logic integrity (the Stuxnet lesson)"],
      link: "controls",
    },
  },
  {
    id: "cloud", name: "Cloud zone (AWS)", x: 740, y: 60, w: 180, h: 250, color: "#EEEDFE",
    detail: {
      title: "Cloud zone (AWS)",
      body: "Where plant and device data goes for scale: workloads (data lake on S3, analytics/ML, IoT Core, device management), services (RDS/Aurora, Lambda, SageMaker, API Gateway), and security services (IAM Identity Center, KMS, CloudWatch, GuardDuty). Increasingly where device telemetry, quality analytics, and fleet management live — which means device data confidentiality and integrity now extend to the cloud.",
      controls: ["IAM least privilege + KMS encryption", "PrivateLink so OT data avoids the public internet", "GuardDuty / CloudWatch for cloud-side detection"],
      link: "controls",
    },
  },
  {
    id: "external", name: "External ecosystem", x: 930, y: 60, w: 90, h: 250, color: "#FAECE7",
    detail: {
      title: "External ecosystem",
      body: "The parties outside your walls you still depend on: suppliers and vendors, service providers, update/patch vendors, and regulators. Each connection is a supply-chain risk — the Norsk Hydro attack began with a weaponized attachment from a trusted customer, and Stuxnet and NotPetya both rode in through the supply chain.",
      controls: ["Security-assess integrators before plant access", "Integrity-verify all vendor updates", "Contractual security requirements"],
      link: "controls",
    },
  },
];

// Attack graph — the path an adversary walks, left column of the reference image.
const ATTACK_GRAPH = [
  { n: 1, name: "Reconnaissance", detail: "Scan internet-facing assets, Shodan, vendor portals to map the target." },
  { n: 2, name: "Initial access", detail: "Phishing, VPN or vendor access, or exploiting a public app to get a foothold." },
  { n: 3, name: "IT compromise", detail: "Credential theft and privilege escalation, then lateral movement across IT." },
  { n: 4, name: "IT→OT pivot", detail: "Cross into OT via a jump host, weak segmentation, or unsecured remote access. This is the boundary the DMZ exists to hold." },
  { n: 5, name: "OT lateral movement", detail: "Move within the control network — HMI, engineering workstation, Historian." },
  { n: 6, name: "Impact on operations", detail: "Manipulate a PLC, stop production, or modify the process. The physical-harm step." },
  { n: 7, name: "Data exfiltration / impact", detail: "Steal IP, recipes, or patient data; deploy ransomware; cause a safety impact." },
];

// Detect & protect column, mapped to NIST-style functions.
const DETECT_PROTECT = {
  Prevent: ["Least privilege, MFA, PAM", "Patch & vulnerability mgmt", "Application allowlisting", "Network segmentation", "Secure remote access"],
  Detect: ["IDS/IPS, NDR, OT anomaly detection", "SIEM / UEBA", "Asset & configuration monitoring", "Endpoint detection (IT/OT)", "Cloud & IoT monitoring"],
  Respond: ["Incident response (IT & OT playbooks)", "OT-safe shutdown procedures", "Containment / isolation", "Forensic collection"],
  Recover: ["Backups (IT/OT/cloud)", "Golden-image restore", "Disaster recovery / BCP"],
};

function zoneById(id) { return ZONES.find(z => z.id === id) || null; }
function attackStep(n) { return ATTACK_GRAPH.find(s => s.n === n) || null; }

if (typeof module !== "undefined") {
  module.exports = { ZONES, ATTACK_GRAPH, DETECT_PROTECT, zoneById, attackStep };
}
