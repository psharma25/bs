const { DOMAINS, domainScore, overallScore, tier, topGaps } = require("./model.js");

let pass = 0, fail = 0; const errs = [];
function ok(n, c, d) { if (c) pass++; else { fail++; errs.push(n + (d ? " :: " + d : "")); } }

// helper: build answers object with every question set to a level
function allAt(level) {
  const a = {};
  DOMAINS.forEach(d => d.questions.forEach(q => { a[q.id] = level; }));
  return a;
}

// all-zero -> 0 overall, Initial tier
let r = overallScore(allAt(0));
ok("all-none scores 0", r.overall === 0, "got " + r.overall);
ok("all-none is Initial tier", tier(r.overall).name === "Initial");

// all-max -> 100 overall, Optimized
r = overallScore(allAt(3));
ok("all-optimized scores 100", r.overall === 100, "got " + r.overall);
ok("all-optimized is Optimized tier", tier(r.overall).name === "Optimized");

// all level 2 (Managed) -> 67, Managed tier
r = overallScore(allAt(2));
ok("all-managed scores 67", r.overall === 67, "got " + r.overall);
ok("all-managed is Managed tier", tier(r.overall).name === "Managed", tier(r.overall).name);

// each domain independently 0..100 at the boundary levels
DOMAINS.forEach(d => {
  const a0 = {}; d.questions.forEach(q => a0[q.id] = 0);
  const a3 = {}; d.questions.forEach(q => a3[q.id] = 3);
  ok("domain " + d.id + " min=0", domainScore(d, a0) === 0);
  ok("domain " + d.id + " max=100", domainScore(d, a3) === 100);
});

// weighting: a high-weight question moves the score more than a low-weight one
const net = DOMAINS.find(d => d.id === "network");
const aHiOnly = {}; net.questions.forEach(q => aHiOnly[q.id] = 0);
aHiOnly["n1"] = 3; // n1 weight 3
const aLoOnly = {}; net.questions.forEach(q => aLoOnly[q.id] = 0);
aLoOnly["n4"] = 3; // n4 weight 2
ok("higher-weight question lifts domain more",
   domainScore(net, aHiOnly) > domainScore(net, aLoOnly),
   `${domainScore(net, aHiOnly)} vs ${domainScore(net, aLoOnly)}`);

// unanswered questions are skipped, not treated as zero
const partial = { g1: 3 }; // only one governance question answered = 3
const gov = DOMAINS.find(d => d.id === "governance");
ok("single answered question scores that question's level",
   domainScore(gov, partial) === 100,
   "got " + domainScore(gov, partial));

// empty answers -> null everywhere, Not assessed
r = overallScore({});
ok("no answers -> overall null", r.overall === null);
ok("null tier is Not assessed", tier(null).name === "Not assessed");

// tier boundaries
ok("29 is Initial", tier(29).name === "Initial");
ok("30 is Developing", tier(30).name === "Developing");
ok("54 is Developing", tier(54).name === "Developing");
ok("55 is Managed", tier(55).name === "Managed");
ok("79 is Managed", tier(79).name === "Managed");
ok("80 is Optimized", tier(80).name === "Optimized");

// top gaps: highest (3-level)*weight*domainWeight first, maxed questions excluded
const gapAns = allAt(3);
gapAns["n1"] = 0; // network n1: weight 3, domain weight 1.3 -> priority 3*3*1.3 = 11.7
gapAns["g4"] = 0; // gov g4: weight 1, domain weight 1.0 -> priority 3*1*1.0 = 3
const gaps = topGaps(gapAns, 5);
ok("top gap is the high-impact one", gaps[0].text === net.questions.find(q => q.id === "n1").text,
   gaps[0] && gaps[0].text);
ok("maxed questions excluded from gaps", gaps.every(g => g.level < 3));
ok("gaps sorted by priority desc",
   gaps.every((g, i) => i === 0 || g.priority <= gaps[i - 1].priority));

// medical-device domain present and flagged
const prod = DOMAINS.find(d => d.id === "product");
ok("product domain is md-focused", prod.mdFocus === true);
ok("product questions flagged mdOnly", prod.questions.every(q => q.mdOnly === true));

// realistic mixed profile lands in a sane band
const mixed = allAt(1); // mostly initial
["a1", "n1", "r1"].forEach(id => mixed[id] = 3); // a few strong controls
r = overallScore(mixed);
ok("mixed-immature profile is Developing or Initial",
   ["Initial", "Developing"].includes(tier(r.overall).name),
   tier(r.overall).name + " @ " + r.overall);

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) { errs.forEach(e => console.log("  FAIL " + e)); process.exit(1); }
console.log("Scoring model verified.");
