/*
 * Manufacturing plant security maturity model.
 * Eight domains, each with weighted questions answered on a 0-3 maturity scale.
 * Domain score = weighted average of its answers, 0-100.
 * Overall = weighted average of domain scores.
 * This is the same data + math that drives the HTML tool.
 */

// Maturity levels an answer can take.
const LEVELS = [
  { v: 0, label: "None", hint: "Not done, or ad hoc" },
  { v: 1, label: "Initial", hint: "Started, inconsistent" },
  { v: 2, label: "Managed", hint: "Documented and repeatable" },
  { v: 3, label: "Optimized", hint: "Measured and continuously improved" },
];

// weight: how much the question counts within its domain.
// mdOnly: true = specific to medical-device manufacturing (shown but flagged).
const DOMAINS = [
  {
    id: "governance",
    name: "Governance & risk",
    blurb: "Ownership, risk assessment, and policy for the plant's cyber-physical risk.",
    weight: 1.0,
    questions: [
      { id: "g1", weight: 2, text: "A named owner is accountable for OT/plant cybersecurity (not just IT)." },
      { id: "g2", weight: 2, text: "Plant cyber-physical risk is assessed and recorded on a schedule." },
      { id: "g3", weight: 1, text: "Security requirements are written into supplier and integrator contracts." },
      { id: "g4", weight: 1, text: "A plant-specific security policy exists and is reviewed annually." },
    ],
  },
  {
    id: "assets",
    name: "Asset & inventory",
    blurb: "You cannot protect what you cannot see. Full OT asset visibility.",
    weight: 1.1,
    questions: [
      { id: "a1", weight: 3, text: "A live inventory of all OT assets (PLCs, HMIs, historians, robots) exists." },
      { id: "a2", weight: 2, text: "Firmware and software versions are tracked per asset." },
      { id: "a3", weight: 2, text: "An SBOM is maintained for software running on production systems." },
      { id: "a4", weight: 1, text: "End-of-life and unpatchable assets are identified and risk-accepted." },
    ],
  },
  {
    id: "network",
    name: "Network segmentation",
    blurb: "Separating plant floor from enterprise IT — the single highest-leverage control.",
    weight: 1.3,
    questions: [
      { id: "n1", weight: 3, text: "OT and IT networks are segmented (Purdue model or equivalent)." },
      { id: "n2", weight: 2, text: "A DMZ mediates all IT-to-OT traffic; no direct flows cross." },
      { id: "n3", weight: 2, text: "Remote access to OT is brokered, MFA-gated, and logged." },
      { id: "n4", weight: 2, text: "Critical process zones are micro-segmented from each other." },
    ],
  },
  {
    id: "access",
    name: "Access control",
    blurb: "Who can touch the line, physically and logically, and least privilege.",
    weight: 1.1,
    questions: [
      { id: "c1", weight: 2, text: "Individual (not shared) accounts are used on HMIs and engineering stations." },
      { id: "c2", weight: 2, text: "Default/vendor passwords on OT devices have been changed." },
      { id: "c3", weight: 2, text: "Physical access to the plant floor and control rooms is controlled and logged." },
      { id: "c4", weight: 1, text: "Removable media (USB) use on OT is blocked or scanned." },
    ],
  },
  {
    id: "monitor",
    name: "Monitoring & detection",
    blurb: "Seeing an attack or anomaly on the plant floor before it reaches product.",
    weight: 1.1,
    questions: [
      { id: "m1", weight: 3, text: "OT network traffic is monitored for anomalies (passive IDS)." },
      { id: "m2", weight: 2, text: "OT logs are collected centrally and retained." },
      { id: "m3", weight: 2, text: "Alerts route to someone who can act on the plant floor 24/7." },
      { id: "m4", weight: 1, text: "Baselines of normal process behavior exist to compare against." },
    ],
  },
  {
    id: "resilience",
    name: "Resilience & recovery",
    blurb: "Getting the line back after ransomware or a destructive incident.",
    weight: 1.2,
    questions: [
      { id: "r1", weight: 3, text: "OT systems and PLC logic are backed up and restore is tested." },
      { id: "r2", weight: 2, text: "An OT-specific incident response plan exists and is exercised." },
      { id: "r3", weight: 2, text: "Manual/degraded operating procedures exist if control systems fail." },
      { id: "r4", weight: 1, text: "Recovery time and data-loss objectives are defined for production." },
    ],
  },
  {
    id: "supply",
    name: "Supply chain & integrity",
    blurb: "Trusting what enters the plant: components, software, and updates.",
    weight: 1.1,
    questions: [
      { id: "s1", weight: 2, text: "Software and firmware updates are integrity-verified before install." },
      { id: "s2", weight: 2, text: "Third-party integrators are security-assessed before plant access." },
      { id: "s3", weight: 2, text: "Component provenance is tracked for security-relevant parts." },
      { id: "s4", weight: 1, text: "A process exists to act on supplier vulnerability disclosures." },
    ],
  },
  {
    id: "product",
    name: "Product integrity (medical device)",
    blurb: "Manufacturing-specific risks to the safety and integrity of the device being built.",
    weight: 1.2,
    mdFocus: true,
    questions: [
      { id: "p1", weight: 3, text: "Manufacturing systems that could alter device safety/quality are identified.", mdOnly: true },
      { id: "p2", weight: 2, text: "Device firmware is signed and provisioned securely on the line.", mdOnly: true },
      { id: "p3", weight: 2, text: "Manufacturing records (DHR) integrity is protected from tampering.", mdOnly: true },
      { id: "p4", weight: 2, text: "Cyber events affecting product quality feed the CAPA/quality system.", mdOnly: true },
    ],
  },
];

function domainScore(domain, answers) {
  let wsum = 0, w = 0;
  for (const q of domain.questions) {
    const a = answers[q.id];
    if (a === undefined || a === null) continue; // unanswered skipped
    wsum += (a / 3) * q.weight;
    w += q.weight;
  }
  if (w === 0) return null;
  return Math.round((wsum / w) * 100);
}

function overallScore(answers) {
  let wsum = 0, w = 0;
  const perDomain = {};
  for (const d of DOMAINS) {
    const s = domainScore(d, answers);
    perDomain[d.id] = s;
    if (s === null) continue;
    wsum += s * d.weight;
    w += d.weight;
  }
  const overall = w === 0 ? null : Math.round(wsum / w);
  return { overall, perDomain };
}

function tier(score) {
  if (score === null) return { name: "Not assessed", band: "none" };
  if (score >= 80) return { name: "Optimized", band: "opt" };
  if (score >= 55) return { name: "Managed", band: "man" };
  if (score >= 30) return { name: "Developing", band: "dev" };
  return { name: "Initial", band: "init" };
}

// Top gaps: answered questions with the lowest maturity, weighted by importance.
function topGaps(answers, n = 5) {
  const gaps = [];
  for (const d of DOMAINS) {
    for (const q of d.questions) {
      const a = answers[q.id];
      if (a === undefined || a === null) continue;
      if (a >= 3) continue;
      gaps.push({
        domain: d.name, text: q.text,
        level: a, weight: q.weight,
        priority: (3 - a) * q.weight * d.weight,
      });
    }
  }
  gaps.sort((x, y) => y.priority - x.priority);
  return gaps.slice(0, n);
}

if (typeof module !== "undefined") {
  module.exports = { LEVELS, DOMAINS, domainScore, overallScore, tier, topGaps };
}
